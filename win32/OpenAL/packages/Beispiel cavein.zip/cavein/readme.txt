 _______  _______           _______            _________ _       
(  ____ \(  ___  )|\     /|(  ____ \           \__   __/( (    /|
| (    \/| (   ) || )   ( || (    \/              ) (   |  \  ( |
| |      | (___) || |   | || (__       _____      | |   |   \ | |
| |      |  ___  |( (   ) )|  __)     (_____)     | |   | (\ \) |
| |      | (   ) | \ \_/ / | (                    | |   | | \   |
| (____/\| )   ( |  \   /  | (____/\           ___) (___| )  \  |
(_______/|/     \|   \_/   (_______/           \_______/|/    )_)
                                                                 
=================================================================

STORY
========

They do not forgive. They do not forget.

.. they live in procedurally generated caves. In a last attempt at
ridding them from your life forever, you sneak into the cave armed
only with your wits (and some dynamite).

You place the dynamite beneath a suspicious blue sphere that marks
the cave's entrance and light the fuse, laughing maniacally at the
ingenius nature of your plan.

But wait... what's that?!

Yes, you're sure of it; it's a golden ring in a box. Imagine how
much you could fetch for it on the surface!

You decide to collect as many rings as you can before the dynamite
seals the cave forever. Flicking on your torch, you step into the
darkness, where they inevitably lurk... waiting.


CONTROLS
========

 - W, A, S, D or Arrow Keys:
   Move yourself around the cave.
   
 - Mouse:
   Turn on the spot and/or direct your torch.
 	 
 - X:
   Exit the cave (when standing beneath the suspicious blue sphere).
 - M:
   Display a map of the cave. (Note: You cannot move whilst viewing the map!)
   
 - F:
   Toggle fullscreen


CREDITS
========

Cave-In was created by Alan Hazelden, John Pennycook and Sarah Marshall for the June 2009 WGD 48 Hour Competition.

The theme was "procedural generation".


